======
Loader
======

.. autoclass:: invoke.loader.Loader
    :special-members:
    :exclude-members: __weakref__

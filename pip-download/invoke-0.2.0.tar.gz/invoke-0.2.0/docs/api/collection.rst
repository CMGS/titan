==========
Collection
==========

.. autoclass:: invoke.collection.Collection
    :special-members:
    :exclude-members: __weakref__

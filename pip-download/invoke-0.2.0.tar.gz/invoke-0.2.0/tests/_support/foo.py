from invoke.tasks import task

@task
def mytask():
    pass
